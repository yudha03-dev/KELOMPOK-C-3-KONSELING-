// File generated manually based on Firebase config
// ignore_for_file: type=lint

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Default [FirebaseOptions] for use with your Firebase apps.
///
/// Example:
/// dart
/// import 'firebase_options.dart';
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
///
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return macos;
      case TargetPlatform.windows:
        return windows;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBg5euFh7nYMItuQ2Isqzcf3Z7yZFQm4CI',
    appId: '1:301824163545:android:1f6991055fa833ceea88c8',
    messagingSenderId: '301824163545',
    projectId: 'bk-flutter-web',
    storageBucket: 'bk-flutter-web.firebasestorage.app',
  );

  /// 🔹 Android Config

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDZXz930PgduVBgnInLn328jZHphyxxkDk',
    appId: '1:301824163545:ios:ae0af8db8d0b8f0aea88c8',
    messagingSenderId: '301824163545',
    projectId: 'bk-flutter-web',
    storageBucket: 'bk-flutter-web.firebasestorage.app',
    iosClientId:
        '301824163545-odpoi3mteiplc9qh7ldsft1rnlm8l855.apps.googleusercontent.com',
    iosBundleId: 'com.example.bk',
  );

  /// 🔹 iOS Config

  static const FirebaseOptions macos = FirebaseOptions(
    apiKey: 'AIzaSyDZXz930PgduVBgnInLn328jZHphyxxkDk',
    appId: '1:301824163545:ios:ae0af8db8d0b8f0aea88c8',
    messagingSenderId: '301824163545',
    projectId: 'bk-flutter-web',
    storageBucket: 'bk-flutter-web.firebasestorage.app',
    iosClientId:
        '301824163545-odpoi3mteiplc9qh7ldsft1rnlm8l855.apps.googleusercontent.com',
    iosBundleId: 'com.example.bk',
  );

  /// 🔹 macOS Config

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyD_tHpvMiYkkaV6frbb9ndz5RAXv7UKkV0',
    appId: '1:301824163545:web:bb15a733596bb0cbea88c8',
    messagingSenderId: '301824163545',
    projectId: 'bk-flutter-web',
    authDomain: 'bk-flutter-web.firebaseapp.com',
    storageBucket: 'bk-flutter-web.firebasestorage.app',
    measurementId: 'G-F7WZ9PJTQV',
  );

  /// 🔹 Windows Config

  /// 🔹 Web Config (yang kamu kirim barusan)
  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyD_tHpvMiYkkaV6frbb9ndz5RAXv7UKkV0',
    appId: '1:301824163545:web:5ef5609e28ddbf96ea88c8',
    messagingSenderId: '301824163545',
    projectId: 'bk-flutter-web',
    authDomain: 'bk-flutter-web.firebaseapp.com',
    storageBucket: 'bk-flutter-web.firebasestorage.app',
    measurementId: 'G-FXQWLY5GSV',
  );
}
