import 'package:flutter/material.dart'; // Paket UI Flutter (ChangeNotifier)
import 'package:firebase_auth/firebase_auth.dart'; // Paket Firebase untuk autentikasi

class AuthProvider extends ChangeNotifier {
  // Provider untuk mengatur login, register, dan logout
  final FirebaseAuth _auth = FirebaseAuth.instance; // Objek utama Firebase Auth
  User? _user; // Variabel untuk menyimpan data user saat ini

  AuthProvider() {
    // Konstruktor: jalan otomatis saat kelas dipanggil
    _user = _auth.currentUser; // Ambil user yang sedang login (jika ada)
    _auth.authStateChanges().listen((user) {
      // Listener untuk memantau perubahan status login
      _user = user; // Update data user
      notifyListeners(); // Beri tahu UI bahwa data berubah
    });
  }

  // 🔹 Getter (untuk akses data dari luar provider)
  User? get user => _user; // Ambil objek user saat ini
  bool get isLoggedIn => _user != null; // True jika user sedang login
  String? get username =>
      _user?.displayName ??
      'Pengguna'; // Ambil nama user, jika kosong tampilkan 'Pengguna'

  // 🔹 REGISTER — membuat akun baru
  Future<String?> register(String name, String email, String password) async {
    try {
      // 1️⃣ Buat akun baru di Firebase Auth
      await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // 2️⃣ Simpan nama ke profil akun Firebase
      await _auth.currentUser?.updateDisplayName(
        name,
      ); // Tambahkan nama pengguna ke akun
      await _auth.currentUser
          ?.reload(); // Refresh data user agar nama tersimpan

      // 3️⃣ Logout otomatis setelah register selesai
      await _auth.signOut(); // Keluarkan user supaya login ulang
      _user = null; // Kosongkan variabel user di aplikasi
      notifyListeners(); // Update tampilan (misal tombol login/register berubah)

      return null; // ✅ Berhasil → tidak ada error
    } on FirebaseAuthException catch (e) {
      // ❌ Jika gagal
      return e.message; // Kembalikan pesan error Firebase
    }
  }

  // 🔹 LOGIN — masuk dengan email & password
  Future<String?> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(
        // Gunakan Firebase untuk login
        email: email,
        password: password,
      );
      _user = _auth.currentUser; // Simpan data user yang baru login
      notifyListeners(); // Perbarui tampilan UI
      return null; // ✅ Login sukses
    } on FirebaseAuthException catch (e) {
      return e.message; // ❌ Gagal login → kirim pesan error
    }
  }

  // 🔹 LOGOUT — keluar dari akun
  Future<void> logout() async {
    await _auth.signOut(); // Logout dari Firebase
    _user = null; // Hapus data user dari memori lokal
    notifyListeners(); // Perbarui UI (misal tampil tombol login lagi)
  }

  // 🔹 RELOAD USER — memuat ulang data user dari Firebase
  Future<void> reloadUser() async {
    await _auth.currentUser?.reload(); // Perbarui data dari server Firebase
    _user = _auth.currentUser; // Simpan ulang data terbaru user
    notifyListeners(); // Perbarui tampilan (misal update nama profil)
  }
}
