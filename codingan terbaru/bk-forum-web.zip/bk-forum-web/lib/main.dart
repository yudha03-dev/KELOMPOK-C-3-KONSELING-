import 'package:flutter/material.dart'; // Paket utama Flutter untuk UI
import 'package:provider/provider.dart'; // Paket untuk state management (Provider)
import 'package:firebase_core/firebase_core.dart'; // Paket untuk inisialisasi Firebase

import 'firebase_options.dart'; // 🔥 File konfigurasi otomatis dari Firebase
import 'provider/forum_provider.dart'; // Provider untuk fitur forum
import 'provider/auth_provider.dart'; // Provider untuk autentikasi user
import 'screens/home_screen.dart'; // Halaman utama aplikasi
import 'screens/login_screen.dart'; // Halaman login aplikasi

// 🔹 Fungsi utama Flutter — program mulai dari sini
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Pastikan binding Flutter siap sebelum inisialisasi async

  // 🔥 Inisialisasi Firebase (wajib sebelum pakai FirebaseAuth / Firestore)
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions
        .currentPlatform, // Gunakan konfigurasi sesuai platform (Android/iOS/Web)
  );

  runApp(const MyApp()); // Jalankan aplikasi utama
}

class MyApp extends StatelessWidget {
  // Widget root aplikasi
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      // Gunakan MultiProvider untuk mengelola banyak provider
      providers: [
        ChangeNotifierProvider(
          create: (_) => ForumProvider(),
        ), // Provider untuk data forum (posting, komentar, dsb)
        ChangeNotifierProvider(
          create: (_) => AuthProvider(),
        ), // Provider untuk autentikasi (login, register)
      ],
      child: MaterialApp(
        // Komponen utama aplikasi Flutter
        debugShowCheckedModeBanner:
            false, // Matikan label "debug" di pojok kanan atas
        title: 'Aplikasi Konseling Sekolah', // Judul aplikasi
        // 🎨 Tema gelap modern (dark mode)
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(
            0xFF1E1E1E,
          ), // Warna latar utama layar
          canvasColor: const Color(
            0xFF2A2A2A,
          ), // Warna dasar komponen (drawer, card)
          textTheme: ThemeData.dark().textTheme.apply(
            fontFamily: 'Roboto', // Gunakan font Roboto di seluruh teks
          ),
          colorScheme: ColorScheme.fromSwatch().copyWith(
            secondary: Colors
                .tealAccent, // Warna aksen (misalnya untuk tombol atau icon aktif)
          ),
        ),

        // 🧭 Tentukan halaman awal berdasarkan status login
        home: Consumer<AuthProvider>(
          // Dengarkan perubahan dari AuthProvider
          builder: (context, auth, _) {
            // 🔹 Jika user sudah login, arahkan ke HomeScreen
            // 🔹 Jika belum, arahkan ke LoginScreen
            return auth.isLoggedIn
                ? const HomeScreen() // ✅ User sudah login → buka Home
                : const LoginScreen(); // ❌ Belum login → tampilkan halaman Login
          },
        ),
      ),
    );
  }
}
