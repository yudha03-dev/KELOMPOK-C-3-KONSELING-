import 'package:flutter/material.dart';
import 'home_screen.dart';

// 🔹 Halaman utama untuk memilih guru BK
class ChatGuruScreen extends StatelessWidget {
  const ChatGuruScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Warna utama dan sekunder
    const Color primaryColor = Colors.white;
    const Color secondaryColor = Colors.blue;

    // 🔹 Daftar guru yang tersedia
    final teachers = [
      {'name': 'Pak Budi', 'subject': 'BK'},
      {'name': 'Ibu Siti', 'subject': 'BK'},
      {'name': 'Pak Andi', 'subject': 'BK'},
    ];

    // 🔹 Tampilan halaman
    return Scaffold(
      backgroundColor: primaryColor,
      appBar: AppBar(
        backgroundColor: secondaryColor,
        title: const Text(
          'PILIH GURU BK',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        // 🔹 Tombol kembali ke HomeScreen
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const HomeScreen()),
            );
          },
        ),
      ),

      // 🔹 Daftar guru dalam bentuk list
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: teachers.length,
          itemBuilder: (ctx, i) {
            final t = teachers[i];
            return Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 10,
                ),
                title: Text(
                  t['name']!, // Nama guru
                  style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  t['subject']!, // Mapel guru
                  style: const TextStyle(color: Colors.black54),
                ),

                // 🔹 Tombol untuk membuka ruang chat
                trailing: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: secondaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ChatRoomScreen(teacherName: t['name']!),
                      ),
                    );
                  },
                  icon: const Icon(Icons.chat_bubble_outline, size: 18),
                  label: const Text('Chat'),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

// ============================================================================
// 🔹 Halaman ruang chat dengan guru yang dipilih
class ChatRoomScreen extends StatefulWidget {
  final String teacherName; // Nama guru dipassing dari halaman sebelumnya
  const ChatRoomScreen({super.key, required this.teacherName});

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final _controller = TextEditingController(); // Untuk input teks
  final List<Map<String, String>> _messages = []; // Menyimpan pesan
  bool _anonymous = true; // Status anonim

  @override
  void dispose() {
    _controller.dispose(); // Membersihkan controller saat widget ditutup
    super.dispose();
  }

  // 🔹 Fungsi kirim pesan
  void _send({required bool anonymous}) {
    final txt = _controller.text.trim();
    if (txt.isEmpty) return; // Cegah pesan kosong
    setState(() {
      // Tambahkan pesan ke daftar
      _messages.add({'from': anonymous ? 'Anonim' : 'Saya', 'text': txt});
    });
    _controller.clear(); // Bersihkan kolom input
  }

  @override
  Widget build(BuildContext context) {
    // Warna tema chat
    const Color backgroundColor = Colors.white;
    const Color bubbleMe = Color(0xFF1976D2); // Biru pesan pengguna
    const Color bubbleOther = Color(0xFFE3F2FD); // Biru muda pesan guru
    const Color appbarColor = Colors.blue;

    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: appbarColor,
        title: Text(
          'Chat ${widget.teacherName}', // Nama guru muncul di app bar
          style: const TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),

      // 🔹 Isi halaman chat
      body: Column(
        children: [
          // 🔹 Daftar pesan (ListView)
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (ctx, i) {
                final m = _messages[i];
                final isMe = m['from'] == 'Saya'; // Cek apakah pesan dari user
                return Align(
                  alignment: isMe
                      ? Alignment
                            .centerRight // Pesan saya di kanan
                      : Alignment.centerLeft, // Pesan guru di kiri
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding: const EdgeInsets.all(10),
                    constraints: const BoxConstraints(maxWidth: 300),
                    decoration: BoxDecoration(
                      color: isMe ? bubbleMe : bubbleOther,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x1A000000), // Bayangan lembut
                          blurRadius: 4,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Nama pengirim
                        Text(
                          m['from']!,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: isMe ? Colors.white70 : Colors.blueGrey,
                          ),
                        ),
                        const SizedBox(height: 4),
                        // Isi pesan
                        Text(
                          m['text']!,
                          style: TextStyle(
                            color: isMe ? Colors.white : Colors.black87,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          // 🔹 Input area di bawah
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              boxShadow: const [
                BoxShadow(
                  color: Color(0x1A000000),
                  blurRadius: 4,
                  offset: Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                // 🔹 Switch Anonim
                Switch(
                  value: _anonymous,
                  activeColor: Colors.blue,
                  onChanged: (v) => setState(() => _anonymous = v),
                ),
                const Text('Anonim', style: TextStyle(color: Colors.black)),
                const SizedBox(width: 8),

                // 🔹 Kolom teks pesan
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: 'Ketik pesan...',
                      filled: true,
                      fillColor: Colors.white,
                      hintStyle: const TextStyle(color: Colors.black54),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Colors.blueAccent,
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                ),

                // 🔹 Tombol kirim
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.blue),
                  onPressed: () => _send(anonymous: _anonymous),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
