import 'package:flutter/material.dart'; // Import pustaka Flutter utama untuk UI

class ForumNonAkademikScreen extends StatefulWidget {
  const ForumNonAkademikScreen({super.key}); // Konstruktor

  @override
  State<ForumNonAkademikScreen> createState() => _ForumNonAkademikScreenState();
}

// ====== STATE CLASS ======
class _ForumNonAkademikScreenState extends State<ForumNonAkademikScreen> {
  // Controller untuk input teks
  final TextEditingController _titleController =
      TextEditingController(); // judul
  final TextEditingController _contentController =
      TextEditingController(); // isi post
  final TextEditingController _replyController =
      TextEditingController(); // balasan
  final TextEditingController _customCategoryController =
      TextEditingController(); // kategori custom

  bool _isAnonymous = false; // status kirim anonim
  String _selectedCategory = 'Konseling'; // kategori default
  bool _isCustomCategory = false; // apakah pilih “Lainnya”

  final List<Map<String, dynamic>> _posts = []; // daftar semua postingan

  // ====== Fungsi menambah postingan ======
  void _addPost() {
    final title = _titleController.text.trim(); // ambil teks judul
    final content = _contentController.text.trim(); // ambil isi
    final category = _isCustomCategory
        ? _customCategoryController.text.trim()
        : _selectedCategory; // pilih kategori dari dropdown atau input manual

    if (content.isEmpty) return; // validasi agar tidak kosong

    setState(() {
      // tambahkan ke list post
      _posts.insert(0, {
        "title": title.isEmpty
            ? "(Tanpa Judul)"
            : title, // fallback jika kosong
        "content": content,
        "category": category.isEmpty ? "Lainnya" : category,
        "anonymous": _isAnonymous, // kirim anonim atau tidak
        "replies": <Map<String, String>>[], // daftar balasan kosong
      });
    });

    // reset semua input
    _titleController.clear();
    _contentController.clear();
    _customCategoryController.clear();
    _isCustomCategory = false;
    _selectedCategory = 'Konseling';
  }

  // ====== Fungsi menambah balasan ======
  void _addReply(int index, String replyText) {
    if (replyText.trim().isEmpty) return; // validasi kosong
    setState(() {
      _posts[index]["replies"].add({
        "content": replyText,
      }); // tambahkan ke list balasan
    });
    _replyController.clear(); // kosongkan kolom
  }

  @override
  Widget build(BuildContext context) {
    // === Paksa tema terang agar dropdown & teks jelas ===
    final lightTheme = ThemeData.light().copyWith(
      canvasColor: Colors.white,
      splashColor: Colors.blue.shade100,
      textTheme: const TextTheme(bodyMedium: TextStyle(color: Colors.black)),
    );

    // ====== Tampilan utama ======
    return Theme(
      data: lightTheme, // pakai tema terang
      child: Scaffold(
        backgroundColor: Colors.blue.shade50, // warna background lembut
        appBar: AppBar(
          title: const Text(
            "Forum Non-Akademik",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.blue, // warna header
          foregroundColor: Colors.white, // teks putih
        ),

        // ====== ISI HALAMAN ======
        body: Column(
          children: [
            // ==== BAGIAN INPUT POST ====
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  // efek bayangan lembut
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16), // jarak dalam
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Label kategori
                  const Text(
                    "Kategori:",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),

                  // ==== Dropdown kategori ====
                  DropdownButtonFormField<String>(
                    value: _isCustomCategory ? "Lainnya" : _selectedCategory,
                    dropdownColor: Colors.white, // dropdown terang
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    // daftar opsi kategori
                    items:
                        [
                              'Konseling',
                              'Hubungan Sosial',
                              'Kedisiplinan',
                              'Kegiatan Sekolah',
                              'Masalah Pribadi',
                              'Lainnya',
                            ]
                            .map(
                              (e) => DropdownMenuItem<String>(
                                value: e,
                                child: Text(
                                  e,
                                  style: const TextStyle(color: Colors.black),
                                ),
                              ),
                            )
                            .toList(),
                    onChanged: (val) {
                      // jika “Lainnya” dipilih maka tampilkan kolom custom
                      setState(() {
                        if (val == "Lainnya") {
                          _isCustomCategory = true;
                        } else {
                          _isCustomCategory = false;
                          _selectedCategory = val!;
                        }
                      });
                    },
                  ),

                  // ==== Input kategori custom ====
                  if (_isCustomCategory) ...[
                    const SizedBox(height: 8),
                    TextField(
                      controller: _customCategoryController,
                      style: const TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                        hintText: "Tulis kategori lainnya...",
                        hintStyle: const TextStyle(color: Colors.black54),
                        prefixIcon: const Icon(
                          Icons.category,
                          color: Colors.blueAccent,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 12),

                  // ==== Input judul ====
                  TextField(
                    controller: _titleController,
                    style: const TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                      hintText: "Judul topik...",
                      hintStyle: const TextStyle(color: Colors.black54),
                      prefixIcon: const Icon(
                        Icons.title,
                        color: Colors.blueAccent,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  // ==== Input isi post ====
                  TextField(
                    controller: _contentController,
                    style: const TextStyle(color: Colors.black),
                    maxLines: 3,
                    decoration: InputDecoration(
                      hintText: "Tulis pertanyaan, curhatan, atau diskusi...",
                      hintStyle: const TextStyle(color: Colors.black54),
                      prefixIcon: const Icon(
                        Icons.edit_note,
                        color: Colors.blueAccent,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),

                  // ==== Tombol anonim + kirim ====
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Switch(
                            value: _isAnonymous, // status anonim
                            activeColor: Colors.white,
                            activeTrackColor: Colors.blue, // warna aktif
                            inactiveThumbColor: Colors.white,
                            inactiveTrackColor: Colors.grey.shade400,
                            onChanged: (val) =>
                                setState(() => _isAnonymous = val),
                          ),
                          const Text(
                            "Kirim sebagai anonim",
                            style: TextStyle(color: Colors.black),
                          ),
                        ],
                      ),
                      // Tombol kirim posting
                      ElevatedButton.icon(
                        onPressed: _addPost,
                        icon: const Icon(Icons.send),
                        label: const Text("Post"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const Divider(), // pemisah antar bagian
            // ==== LIST POSTINGAN ====
            Expanded(
              child: _posts.isEmpty
                  ? const Center(
                      child: Text(
                        "Belum ada diskusi non-akademik",
                        style: TextStyle(color: Colors.black54),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _posts.length,
                      itemBuilder: (context, index) {
                        final post = _posts[index];
                        return Card(
                          color: Colors.white,
                          elevation: 2,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Nama pengirim
                                Text(
                                  post["anonymous"] ? "Anonim" : "Siswa",
                                  style: const TextStyle(
                                    color: Colors.blue,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),

                                // Judul dan kategori
                                Text(
                                  "[${post["category"]}] ${post["title"]}",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black,
                                  ),
                                ),
                                const SizedBox(height: 6),

                                // Isi posting
                                Text(
                                  post["content"],
                                  style: const TextStyle(color: Colors.black),
                                ),
                                const SizedBox(height: 8),

                                // ==== BALASAN ====
                                if (post["replies"].isNotEmpty)
                                  Container(
                                    margin: const EdgeInsets.only(
                                      left: 16,
                                      top: 6,
                                    ),
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Colors.blue.shade50,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: post["replies"]
                                          .map<Widget>(
                                            (reply) => Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    vertical: 3,
                                                  ),
                                              child: Text(
                                                "↳ ${reply["content"]}",
                                                style: const TextStyle(
                                                  color: Colors.black,
                                                ),
                                              ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  ),

                                const SizedBox(height: 8),

                                // ==== KOLOM BALAS ====
                                Row(
                                  children: [
                                    Expanded(
                                      child: TextField(
                                        controller: _replyController,
                                        style: const TextStyle(
                                          color: Colors.black,
                                        ),
                                        decoration: InputDecoration(
                                          hintText: "Tulis balasan...",
                                          hintStyle: const TextStyle(
                                            color: Colors.black54,
                                          ),
                                          isDense: true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () => _addReply(
                                        index,
                                        _replyController.text,
                                      ),
                                      icon: const Icon(
                                        Icons.reply,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
