import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/auth_provider.dart';
import 'chat_guru_screen.dart';
import 'login_screen.dart';
import 'forum_akademik_screen.dart';
import 'forum_nonakademik_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(
      context,
    ); // ✅ Ambil data user dari provider
    final userEmail =
        auth.user?.displayName ??
        auth.user?.email ??
        "Pengguna"; // ✅ Nama user atau email

    // ✅ Ambil nama depan (misal: “andi@gmail.com” → “andi”)
    final firstName = userEmail.contains('@')
        ? userEmail.split('@')[0]
        : userEmail.split(' ').first;

    // 🎨 Warna tema utama aplikasi
    const Color primaryColor = Colors.black; // Warna teks utama
    final Color backgroundColor = Colors.white; // Warna latar belakang
    const Color buttonColor = Colors.black; // Warna tombol menu
    const Color buttonTextColor = Colors.white; // Warna teks tombol

    return Scaffold(
      backgroundColor: backgroundColor, // ✅ Set warna background
      appBar: AppBar(
        backgroundColor: Colors.white, // Warna AppBar
        elevation: 2, // Efek bayangan kecil di bawah AppBar
        title: const Text(
          "BK FORUM",
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.1, // Spasi antar huruf
          ),
        ),
        actions: [
          // ✅ Menu titik tiga di kanan atas
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.black),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            onSelected: (value) async {
              if (value == 'profile') {
                // Jika pilih “Profil”
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfileScreen()),
                );
              } else if (value == 'logout') {
                // Jika pilih “Logout”
                await auth.logout();
                if (!context.mounted) return;
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false, // Hapus semua route sebelumnya
                );
              }
            },
            itemBuilder: (context) => [
              // ✅ Daftar menu popup
              const PopupMenuItem(
                value: 'profile',
                child: Row(
                  children: [
                    Icon(Icons.person, color: Colors.black54),
                    SizedBox(width: 10),
                    Text("Profil"),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout, color: Colors.redAccent),
                    SizedBox(width: 10),
                    Text("Logout"),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),

      // ===== BODY =====
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            bool isMobile =
                constraints.maxWidth < 600; // ✅ Cek tampilan mobile / tablet
            double boxPadding = isMobile ? 16 : 32; // Padding dinamis

            return Padding(
              padding: EdgeInsets.all(boxPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 20),

                  // ===== HEADER =====
                  Text(
                    "SELAMAT DATANG",
                    style: TextStyle(
                      fontSize: isMobile ? 24 : 30, // Responsif ukuran teks
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      letterSpacing: 1.2,
                    ),
                  ),
                  Text(
                    firstName.toUpperCase(), // ✅ Nama user kapital
                    style: TextStyle(
                      fontSize: isMobile ? 20 : 26,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                    ),
                  ),

                  const SizedBox(height: 40),

                  // ===== MENU UTAMA =====
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: isMobile
                          ? 1
                          : 2, // ✅ 1 kolom di HP, 2 kolom di tablet
                      crossAxisSpacing: 16, // Jarak antar kolom
                      mainAxisSpacing: 16, // Jarak antar baris
                      childAspectRatio: isMobile
                          ? 3.5
                          : 3, // Proporsi tinggi-lebar
                      children: [
                        // ✅ Menu Chat Guru
                        _menuCard(
                          title: "CHAT GURU",
                          color: buttonColor,
                          textColor: buttonTextColor,
                          icon: Icons.chat,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const ChatGuruScreen(),
                              ),
                            );
                          },
                        ),

                        // ✅ Menu Akademik
                        _menuCard(
                          title: "AKADEMIK",
                          color: buttonColor,
                          textColor: buttonTextColor,
                          icon: Icons.school,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const ForumAkademikScreen(),
                              ),
                            );
                          },
                        ),

                        // ✅ Menu Non Akademik
                        _menuCard(
                          title: "NON AKADEMIK",
                          color: buttonColor,
                          textColor: buttonTextColor,
                          icon: Icons.groups_2_rounded,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const ForumNonAkademikScreen(),
                              ),
                            );
                          },
                        ),

                        // ✅ Menu Riwayat Chat (belum aktif)
                        _menuCard(
                          title: "RIWAYAT CHAT",
                          color: buttonColor,
                          textColor: buttonTextColor,
                          icon: Icons.history_rounded,
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  "Fitur Riwayat Chat akan segera hadir 🚧",
                                  style: TextStyle(fontSize: 14),
                                ),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ===== WIDGET MENU CARD =====
  Widget _menuCard({
    required String title,
    required Color color,
    required Color textColor,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap, // ✅ Klik kartu jalankan fungsi
      child: Container(
        decoration: BoxDecoration(
          color: color, // Warna background kartu
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.15), // Efek bayangan lembut
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment:
              MainAxisAlignment.center, // Tengah secara horizontal
          children: [
            Icon(icon, color: textColor, size: 22), // Ikon menu
            const SizedBox(width: 10),
            Text(
              title,
              style: TextStyle(
                color: textColor, // Warna teks
                fontWeight: FontWeight.bold,
                letterSpacing: 1.1, // Spasi antar huruf
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
