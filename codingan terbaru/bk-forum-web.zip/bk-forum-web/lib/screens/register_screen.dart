import 'package:flutter/material.dart'; // Paket UI utama Flutter
import 'package:provider/provider.dart'; // Paket untuk state management
import '../provider/auth_provider.dart'; // Provider autentikasi (Firebase / custom)

class RegisterScreen extends StatefulWidget {
  // Gunakan StatefulWidget agar bisa ubah state (misal show/hide password)
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>(); // 🔹 Kunci untuk validasi form
  final _nameCtl = TextEditingController(); // 🔹 Controller untuk input nama
  final _emailCtl = TextEditingController(); // 🔹 Controller untuk input email
  final _passwordCtl =
      TextEditingController(); // 🔹 Controller untuk input password
  bool _obscurePassword = true; // 🔹 Untuk sembunyikan atau tampilkan password

  // 🎨 Warna tema utama
  final Color primaryColor = const Color(0xFF2563EB); // Warna biru utama
  final Color backgroundColor = const Color(
    0xFFF3F4F6,
  ); // Warna background abu muda
  final Color textColor = Colors.black87; // Warna teks utama

  // 🧾 Fungsi untuk registrasi akun baru
  Future<void> _register() async {
    if (!_formKey.currentState!.validate())
      return; // Jika form belum valid, hentikan proses

    final auth = Provider.of<AuthProvider>(
      context,
      listen: false,
    ); // Ambil instance AuthProvider
    String? error = await auth.register(
      // Jalankan fungsi register dari provider
      _nameCtl.text.trim(), // Kirim nama tanpa spasi depan/belakang
      _emailCtl.text.trim(), // Kirim email
      _passwordCtl.text.trim(), // Kirim password
    );

    if (!mounted) return; // Pastikan widget masih aktif
    if (error == null) {
      // ✅ Registrasi berhasil
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("✅ Registrasi berhasil! Silakan login.")),
      );
      Navigator.pop(context); // Kembali ke halaman login
    } else {
      // ❌ Jika gagal
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error)), // Tampilkan pesan error
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor, // Warna latar belakang abu muda
      body: LayoutBuilder(
        // Responsif: bedakan antara mobile dan web
        builder: (context, constraints) {
          bool isMobile =
              constraints.maxWidth < 600; // Jika layar <600 → mode mobile

          return Center(
            child: SingleChildScrollView(
              // Scroll jika konten panjang
              padding: const EdgeInsets.all(24),
              child: Container(
                width: isMobile
                    ? double.infinity
                    : 400, // Batasi lebar maksimal di layar besar
                padding: const EdgeInsets.all(28),
                decoration: BoxDecoration(
                  // Kotak putih di tengah
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20), // Sudut melengkung
                  boxShadow: [
                    // Efek bayangan
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),

                // 🧾 Form utama untuk input data
                child: Form(
                  key: _formKey, // Hubungkan key form
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        // 🔹 Ikon header
                        Icons.person_add_alt_1,
                        size: 64,
                        color: primaryColor,
                      ),
                      const SizedBox(height: 16),

                      Text(
                        // 🧾 Judul "REGISTER"
                        "REGISTER",
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: primaryColor,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 30),

                      // 🧍 Input Nama Lengkap
                      TextFormField(
                        controller:
                            _nameCtl, // Hubungkan dengan controller nama
                        style: TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: "Nama Lengkap", // Label input
                          prefixIcon: Icon(
                            // Ikon orang di depan input
                            Icons.person_outline,
                            color: primaryColor,
                          ),
                          border: OutlineInputBorder(
                            // Gaya border
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        validator: (v) => v!.isEmpty
                            ? 'Masukkan nama lengkap'
                            : null, // Validasi wajib isi
                      ),
                      const SizedBox(height: 18),

                      // 📧 Input Email
                      TextFormField(
                        controller: _emailCtl,
                        style: TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: "Email", // Label input email
                          prefixIcon: Icon(
                            Icons.email_outlined, // Ikon email
                            color: primaryColor,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        validator: (v) => v!.isEmpty
                            ? 'Masukkan email'
                            : null, // Validasi wajib isi
                      ),
                      const SizedBox(height: 18),

                      // 🔑 Input Password
                      TextFormField(
                        controller:
                            _passwordCtl, // Hubungkan controller password
                        obscureText:
                            _obscurePassword, // Sembunyikan teks jika true
                        style: TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: "Password",
                          prefixIcon: Icon(
                            Icons.lock_outline, // Ikon kunci
                            color: primaryColor,
                          ),
                          suffixIcon: IconButton(
                            // Tombol mata (show/hide)
                            icon: Icon(
                              _obscurePassword
                                  ? Icons
                                        .visibility_off // Jika tersembunyi
                                  : Icons.visibility, // Jika terlihat
                              color: primaryColor,
                            ),
                            onPressed: () {
                              // Ubah state ketika ditekan
                              setState(() {
                                _obscurePassword = !_obscurePassword;
                              });
                            },
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        validator: (v) => v!.isEmpty
                            ? 'Masukkan password'
                            : null, // Validasi wajib isi
                      ),
                      const SizedBox(height: 30),

                      // 🔵 Tombol DAFTAR
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor, // Warna tombol biru
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed:
                              _register, // Jalankan fungsi register saat ditekan
                          child: const Text(
                            "Daftar", // Teks tombol
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // 🔗 Link ke halaman Login
                      TextButton(
                        onPressed: () => Navigator.pop(
                          context,
                        ), // Balik ke halaman sebelumnya (Login)
                        child: Text(
                          "Sudah punya akun? Login di sini",
                          style: TextStyle(
                            color: primaryColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
