import 'package:flutter/material.dart';

class ForumAkademikScreen extends StatefulWidget {
  const ForumAkademikScreen({super.key});

  @override
  State<ForumAkademikScreen> createState() => _ForumAkademikScreenState();
}

class _ForumAkademikScreenState extends State<ForumAkademikScreen> {
  // ✏️ Controller untuk menampung input pengguna
  final TextEditingController _titleController =
      TextEditingController(); // untuk judul
  final TextEditingController _contentController =
      TextEditingController(); // untuk isi posting
  final TextEditingController _replyController =
      TextEditingController(); // untuk balasan
  final TextEditingController _customSubjectController =
      TextEditingController(); // untuk input mata pelajaran custom

  // ⚙️ Variabel status forum
  bool _isAnonymous = false; // jika true, posting dikirim anonim
  String _selectedSubject = 'Matematika'; // pilihan default dropdown
  bool _isCustomSubject =
      false; // apakah pengguna sedang mengetik sendiri "Lainnya"

  // 📋 List untuk menyimpan semua postingan
  final List<Map<String, dynamic>> _posts = [];

  // 🟦 Tambah posting baru ke daftar
  void _addPost() {
    final subject = _isCustomSubject
        ? _customSubjectController.text
              .trim() // kalau custom, ambil dari input
        : _selectedSubject; // kalau tidak, ambil dari dropdown

    // Cegah posting kosong
    if (_contentController.text.trim().isEmpty || subject.isEmpty) return;

    // Tambah ke list
    setState(() {
      _posts.insert(0, {
        "title": _titleController.text.trim(),
        "content": _contentController.text.trim(),
        "subject": subject,
        "anonymous": _isAnonymous,
        "replies": <Map<String, String>>[],
      });
    });

    // Bersihkan input
    _titleController.clear();
    _contentController.clear();
    _customSubjectController.clear();
  }

  // 🟨 Tambah balasan ke posting tertentu
  void _addReply(int index, String replyText) {
    if (replyText.trim().isEmpty) return;
    setState(() {
      _posts[index]["replies"].add({"content": replyText});
    });
    _replyController.clear();
  }

  @override
  Widget build(BuildContext context) {
    // 🎨 Tema terang untuk dropdown
    final lightTheme = ThemeData.light().copyWith(
      canvasColor: Colors.white,
      primaryColor: Colors.blueAccent,
      splashColor: Colors.blue.shade100,
      textTheme: const TextTheme(bodyMedium: TextStyle(color: Colors.black)),
    );

    return Theme(
      data: lightTheme,
      child: Scaffold(
        backgroundColor: Colors.blue.shade50, // warna latar belakang utama
        appBar: AppBar(
          title: const Text(
            "Forum Akademik",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.blueAccent,
          foregroundColor: Colors.white,
        ),

        // ===================== BODY UTAMA ===================== //
        body: Column(
          children: [
            // ==== AREA INPUT POST ====
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 4,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Mata Pelajaran:",
                    style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 4),

                  // ==== DROPDOWN PILIH MAPEL ====
                  DropdownButtonFormField<String>(
                    value: _isCustomSubject ? 'Lainnya' : _selectedSubject,
                    dropdownColor: Colors.white, // biar background terang
                    decoration: InputDecoration(
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    items:
                        [
                              'Matematika',
                              'Fisika',
                              'Kimia',
                              'Biologi',
                              'Bahasa Inggris',
                              'Ekonomi',
                              'Lainnya',
                            ]
                            .map(
                              (e) => DropdownMenuItem<String>(
                                value: e,
                                child: Text(
                                  e,
                                  style: const TextStyle(color: Colors.black),
                                ),
                              ),
                            )
                            .toList(),
                    onChanged: (val) {
                      // kalau pilih "Lainnya", tampilkan textfield tambahan
                      setState(() {
                        if (val == 'Lainnya') {
                          _isCustomSubject = true;
                          _customSubjectController.clear();
                        } else {
                          _isCustomSubject = false;
                          _selectedSubject = val!;
                        }
                      });
                    },
                  ),

                  // ==== INPUT CUSTOM MAPEL (muncul kalau pilih "Lainnya") ====
                  if (_isCustomSubject) ...[
                    const SizedBox(height: 8),
                    TextField(
                      controller: _customSubjectController,
                      style: const TextStyle(color: Colors.black),
                      decoration: InputDecoration(
                        hintText: "Ketik mata pelajaran sendiri...",
                        hintStyle: const TextStyle(color: Colors.black54),
                        prefixIcon: const Icon(
                          Icons.book,
                          color: Colors.blueAccent,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 12),

                  // ==== INPUT JUDUL ====
                  TextField(
                    controller: _titleController,
                    style: const TextStyle(color: Colors.black),
                    decoration: InputDecoration(
                      hintText: "Judul singkat...",
                      hintStyle: const TextStyle(color: Colors.black54),
                      prefixIcon: const Icon(
                        Icons.title,
                        color: Colors.blueAccent,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),

                  const SizedBox(height: 8),

                  // ==== INPUT ISI ====
                  TextField(
                    controller: _contentController,
                    style: const TextStyle(color: Colors.black),
                    maxLines: 3, // bisa nulis panjang
                    decoration: InputDecoration(
                      hintText: "Tulis pertanyaan atau diskusi...",
                      hintStyle: const TextStyle(color: Colors.black54),
                      prefixIcon: const Icon(
                        Icons.edit_note,
                        color: Colors.blueAccent,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),

                  const SizedBox(height: 8),

                  // ==== SWITCH ANONIM + TOMBOL POST ====
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Switch(
                            value: _isAnonymous,
                            activeColor: Colors.white,
                            activeTrackColor: Colors.blueAccent,
                            inactiveThumbColor: Colors.white,
                            inactiveTrackColor: Colors.grey.shade400,
                            onChanged: (val) =>
                                setState(() => _isAnonymous = val),
                          ),
                          const Text(
                            "Kirim sebagai anonim",
                            style: TextStyle(color: Colors.black),
                          ),
                        ],
                      ),
                      ElevatedButton.icon(
                        onPressed: _addPost, // kirim postingan
                        icon: const Icon(Icons.send),
                        label: const Text("Post"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueAccent,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const Divider(),

            // ==== LIST POSTING ====
            Expanded(
              child: _posts.isEmpty
                  // Kalau belum ada posting
                  ? const Center(
                      child: Text(
                        "Belum ada diskusi",
                        style: TextStyle(color: Colors.black54),
                      ),
                    )
                  // Kalau ada posting
                  : ListView.builder(
                      itemCount: _posts.length,
                      itemBuilder: (context, index) {
                        final post = _posts[index];
                        return Card(
                          color: Colors.white,
                          elevation: 2,
                          margin: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // 🔹 Nama pengirim (anonim atau siswa)
                                Text(
                                  post["anonymous"] ? "Anonim" : "Siswa",
                                  style: const TextStyle(
                                    color: Colors.blueAccent,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(height: 4),

                                // 🔹 Judul + mapel
                                Text(
                                  "[${post["subject"]}] ${post["title"]}",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.black,
                                  ),
                                ),
                                const SizedBox(height: 6),

                                // 🔹 Isi posting
                                Text(
                                  post["content"],
                                  style: const TextStyle(color: Colors.black),
                                ),
                                const SizedBox(height: 8),

                                // 🔹 Balasan
                                if (post["replies"].isNotEmpty)
                                  Container(
                                    margin: const EdgeInsets.only(
                                      left: 16,
                                      top: 6,
                                    ),
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Colors.blue.shade50,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: post["replies"]
                                          .map<Widget>(
                                            (reply) => Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    vertical: 3,
                                                  ),
                                              child: Text(
                                                "↳ ${reply["content"]}",
                                                style: const TextStyle(
                                                  color: Colors.black,
                                                ),
                                              ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  ),

                                const SizedBox(height: 8),

                                // 🔹 Kolom untuk membalas postingan
                                Row(
                                  children: [
                                    Expanded(
                                      child: TextField(
                                        controller: _replyController,
                                        style: const TextStyle(
                                          color: Colors.black,
                                        ),
                                        decoration: InputDecoration(
                                          hintText: "Tulis balasan...",
                                          hintStyle: const TextStyle(
                                            color: Colors.black54,
                                          ),
                                          isDense: true,
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    IconButton(
                                      onPressed: () => _addReply(
                                        index,
                                        _replyController.text,
                                      ),
                                      icon: const Icon(
                                        Icons.reply,
                                        color: Colors.blueAccent,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
