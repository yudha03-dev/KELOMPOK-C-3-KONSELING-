import 'package:flutter/material.dart'; // Paket UI utama Flutter
import 'package:provider/provider.dart'; // Paket untuk state management (Provider)
import '../provider/auth_provider.dart'; // ✅ File AuthProvider untuk autentikasi
import 'register_screen.dart'; // ✅ Layar daftar pengguna baru
import 'home_screen.dart'; // ✅ Layar utama setelah login berhasil

class LoginScreen extends StatefulWidget {
  // StatefulWidget agar bisa ubah state (misal toggle password)
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>(); // 🔹 Kunci untuk validasi form
  final _emailCtl = TextEditingController(); // 🔹 Controller input email
  final _passwordCtl = TextEditingController(); // 🔹 Controller input password
  bool _obscurePassword = true; // 🔹 Untuk show/hide password

  // 🎨 Warna tema aplikasi
  final Color primaryColor = const Color(0xFF2563EB); // Biru utama
  final Color backgroundColor = const Color(
    0xFFF3F4F6,
  ); // Abu muda (background)
  final Color textColor = Colors.black87; // Warna teks utama

  // 🔹 Fungsi login utama
  Future<void> _login() async {
    if (!_formKey.currentState!.validate())
      return; // Validasi form sebelum login
    final auth = Provider.of<AuthProvider>(
      context,
      listen: false,
    ); // Ambil instance AuthProvider

    String? error = await auth.login(
      // Coba login ke Firebase
      _emailCtl.text.trim(), // Ambil email dari TextField
      _passwordCtl.text.trim(), // Ambil password dari TextField
    );

    if (error == null) {
      // ✅ Login berhasil
      Navigator.pushReplacement(
        // Pindah ke HomeScreen (hapus halaman login)
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
      );
    } else {
      // ❌ Login gagal
      ScaffoldMessenger.of(context).showSnackBar(
        // Tampilkan pesan error
        SnackBar(content: Text(error)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor, // Set warna background
      body: LayoutBuilder(
        // Untuk tampilan responsif (mobile/web)
        builder: (context, constraints) {
          bool isMobile =
              constraints.maxWidth <
              600; // Jika lebar layar < 600 → tampilkan mode mobile

          return Center(
            child: SingleChildScrollView(
              // Scroll jika layar kecil
              padding: const EdgeInsets.all(24.0),
              child: Container(
                width: isMobile
                    ? double.infinity
                    : 400, // Batasi lebar di layar besar
                padding: const EdgeInsets.all(28.0),
                decoration: BoxDecoration(
                  // Kotak putih di tengah
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    // Bayangan lembut
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),

                // 🧾 Form utama
                child: Form(
                  key: _formKey, // Pasangkan key form
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.lock_outline, // 🔒 Ikon login di atas
                        size: 64,
                        color: primaryColor,
                      ),
                      const SizedBox(height: 16),

                      Text(
                        // 🧾 Judul besar LOGIN
                        "LOGIN",
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: primaryColor,
                          letterSpacing: 1.5,
                        ),
                      ),
                      const SizedBox(height: 30),

                      // 📧 Input Email
                      TextFormField(
                        controller: _emailCtl, // Hubungkan ke controller email
                        style: TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: "Email",
                          prefixIcon: Icon(
                            Icons.email_outlined,
                            color: primaryColor,
                          ), // Ikon di depan
                          border: OutlineInputBorder(
                            // Border input
                            borderRadius: BorderRadius.circular(12),
                          ),
                          focusedBorder: OutlineInputBorder(
                            // Warna border saat fokus
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: primaryColor),
                          ),
                        ),
                        validator: (v) => v!.isEmpty
                            ? 'Masukkan email'
                            : null, // Validasi wajib isi
                      ),
                      const SizedBox(height: 18),

                      // 🔑 Input Password
                      TextFormField(
                        controller: _passwordCtl,
                        obscureText:
                            _obscurePassword, // Sembunyikan teks password
                        style: TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: "Password",
                          prefixIcon: Icon(
                            Icons.lock_outline,
                            color: primaryColor,
                          ),
                          suffixIcon: IconButton(
                            // Tombol tampilkan/sembunyikan password
                            icon: Icon(
                              _obscurePassword
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                              color: primaryColor,
                            ),
                            onPressed: () {
                              // Toggle visibilitas password
                              setState(() {
                                _obscurePassword = !_obscurePassword;
                              });
                            },
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: primaryColor),
                          ),
                        ),
                        validator: (v) => v!.isEmpty
                            ? 'Masukkan password'
                            : null, // Validasi wajib isi
                      ),
                      const SizedBox(height: 30),

                      // 🔵 Tombol Login
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor, // Warna tombol
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 3,
                          ),
                          onPressed: _login, // Jalankan fungsi login
                          child: const Text(
                            "Masuk",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),

                      // 🔗 Link ke halaman Register
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            // Navigasi ke RegisterScreen
                            context,
                            MaterialPageRoute(
                              builder: (_) => const RegisterScreen(),
                            ),
                          );
                        },
                        child: Text(
                          "Belum punya akun? Daftar di sini", // Teks link daftar
                          style: TextStyle(
                            color: primaryColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
