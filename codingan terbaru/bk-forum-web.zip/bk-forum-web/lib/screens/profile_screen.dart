import 'dart:io'; // Untuk akses file di perangkat (mobile)
import 'dart:typed_data'; // Untuk menyimpan data gambar (Web)
import 'package:flutter/foundation.dart'; // Untuk deteksi platform (kIsWeb)
import 'package:flutter/material.dart'; // Paket utama Flutter UI
import 'package:image_picker/image_picker.dart'; // Paket untuk memilih gambar dari galeri
import 'package:firebase_storage/firebase_storage.dart'; // Paket untuk upload gambar ke Firebase Storage
import 'package:provider/provider.dart'; // State management
import '../provider/auth_provider.dart'; // Import AuthProvider (data user)
import 'login_screen.dart'; // Import halaman login

// ===========================================================
// 🧩 HALAMAN PROFIL USER
// ===========================================================
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _nameController =
      TextEditingController(); // Controller untuk input nama
  Uint8List? _webImage; // Menyimpan gambar versi web (bytes)
  File? _imageFile; // Menyimpan gambar versi mobile (File)
  bool _isLoading = false; // Menandakan proses simpan sedang berjalan

  // ===========================================================
  // 📸 PILIH GAMBAR DARI GALERI
  // ===========================================================
  Future<void> _pickImage() async {
    final picker = ImagePicker(); // Buat instance ImagePicker
    final pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
    ); // Pilih gambar dari galeri

    if (pickedFile != null) {
      // Jika user memilih gambar
      if (kIsWeb) {
        // Jika dijalankan di Web
        final bytes = await pickedFile.readAsBytes(); // Baca gambar jadi bytes
        setState(() => _webImage = bytes); // Simpan ke variabel _webImage
      } else {
        // Jika dijalankan di Mobile
        setState(
          () => _imageFile = File(pickedFile.path),
        ); // Simpan ke variabel _imageFile
      }
    }
  }

  // ===========================================================
  // 💾 SIMPAN PROFIL KE FIREBASE
  // ===========================================================
  Future<void> _saveProfile(AuthProvider auth) async {
    final user = auth.user; // Ambil user aktif dari AuthProvider
    if (user == null) return;

    setState(() => _isLoading = true); // Tampilkan loading spinner
    String? photoUrl = user.photoURL; // Simpan foto lama jika tidak diubah
    final newName = _nameController.text.trim(); // Ambil nama baru dari input

    try {
      // ✅ Upload foto ke Firebase Storage
      if (_imageFile != null || _webImage != null) {
        // Jika user memilih foto baru
        final ref = FirebaseStorage.instance
            .ref()
            .child('profile_pics') // Folder di Firebase Storage
            .child('${user.uid}.jpg'); // Nama file = userID.jpg

        if (kIsWeb && _webImage != null) {
          await ref.putData(_webImage!); // Upload versi web (pakai bytes)
        } else if (!kIsWeb && _imageFile != null) {
          await ref.putFile(_imageFile!); // Upload versi mobile (pakai File)
        }

        photoUrl = await ref.getDownloadURL(); // Ambil URL gambar dari Firebase
      }

      // ✅ Update profil user di Firebase Auth
      await user.updateDisplayName(
        newName.isNotEmpty
            ? newName
            : user.displayName, // Ganti nama jika tidak kosong
      );
      if (photoUrl != null)
        await user.updatePhotoURL(photoUrl); // Ganti foto profil
      await auth.reloadUser(); // Refresh data user di AuthProvider

      // ✅ Tampilkan notifikasi sukses
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profil berhasil diperbarui ✅')),
        );
      }
    } catch (e) {
      // ❌ Tampilkan pesan error jika gagal
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Gagal memperbarui profil: $e')));
      }
    } finally {
      if (mounted) setState(() => _isLoading = false); // Sembunyikan loading
    }
  }

  // ===========================================================
  // 🎨 TAMPILAN UTAMA PROFIL
  // ===========================================================
  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(
      context,
    ); // Ambil data user dari Provider
    final user = auth.user;
    _nameController.text =
        user?.displayName ?? ''; // Isi textfield nama dengan nama user

    // 🔹 Tentukan gambar yang akan ditampilkan
    ImageProvider? imageProvider;
    if (kIsWeb && _webImage != null) {
      imageProvider = MemoryImage(
        _webImage!,
      ); // Jika user baru pilih foto di Web
    } else if (!kIsWeb && _imageFile != null) {
      imageProvider = FileImage(
        _imageFile!,
      ); // Jika user baru pilih foto di Mobile
    } else if (user?.photoURL != null) {
      imageProvider = NetworkImage(
        user!.photoURL!,
      ); // Jika sudah ada foto profil di Firebase
    }

    // 🎨 Tema warna
    const primaryColor = Color(0xFF2563EB); // Biru lembut
    const backgroundColor = Color(0xFFF3F4F6); // Abu muda (latar belakang)
    const cardColor = Colors.white; // Warna kartu profil
    const textColor = Colors.black; // Warna teks utama

    return Scaffold(
      backgroundColor: backgroundColor, // Warna latar belakang
      appBar: AppBar(
        elevation: 0,
        backgroundColor: primaryColor,
        title: const Text(
          'Profil Saya', // Judul app bar
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        actions: [
          // 🔴 Tombol Logout di kanan atas
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white),
            onPressed: () async {
              await auth.logout(); // Logout user
              if (!context.mounted) return;
              Navigator.pushAndRemoveUntil(
                // Kembali ke login
                context,
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),

      // 🔄 Jika sedang menyimpan tampilkan loading spinner
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: primaryColor))
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Center(
                child: Container(
                  width: 500, // Lebar maksimum card
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // =======================================================
                      // 🖼️ FOTO PROFIL + TOMBOL EDIT
                      // =======================================================
                      Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          CircleAvatar(
                            radius: 60,
                            backgroundColor: Colors.grey.shade200,
                            backgroundImage: imageProvider, // Foto profil user
                            child: imageProvider == null
                                ? const Icon(
                                    Icons.person,
                                    size: 70,
                                    color: Colors.grey,
                                  )
                                : null,
                          ),
                          Positioned(
                            bottom: 4,
                            right: 4,
                            child: InkWell(
                              onTap: _pickImage, // Klik untuk ganti foto
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: primaryColor,
                                ),
                                child: const Icon(
                                  Icons.edit,
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 30),

                      // =======================================================
                      // ✏️ INPUT NAMA LENGKAP
                      // =======================================================
                      TextField(
                        controller: _nameController,
                        style: const TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: 'Nama Lengkap',
                          labelStyle: const TextStyle(color: textColor),
                          prefixIcon: const Icon(
                            Icons.person,
                            color: textColor,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          focusedBorder: const OutlineInputBorder(
                            borderSide: BorderSide(color: primaryColor),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // =======================================================
                      // 📧 TAMPILAN EMAIL (HANYA BACA)
                      // =======================================================
                      TextField(
                        readOnly: true, // Tidak bisa diubah
                        style: const TextStyle(color: textColor),
                        decoration: InputDecoration(
                          labelText: 'Email',
                          labelStyle: const TextStyle(color: textColor),
                          hintText:
                              user?.email ?? '-', // Menampilkan email user
                          hintStyle: const TextStyle(color: textColor),
                          prefixIcon: const Icon(Icons.email, color: textColor),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),

                      // =======================================================
                      // 💾 TOMBOL SIMPAN PERUBAHAN
                      // =======================================================
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: primaryColor,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 2,
                          ),
                          onPressed: () =>
                              _saveProfile(auth), // Jalankan fungsi simpan
                          icon: const Icon(Icons.save, color: Colors.white),
                          label: const Text(
                            'Simpan Perubahan',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}
