import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'services/chat_service.dart';

class ChatGuruPage extends StatefulWidget {
  final String guruId;
  final String guruName;

  const ChatGuruPage({
    super.key,
    required this.guruId,
    required this.guruName,
  });

  @override
  State<ChatGuruPage> createState() => _ChatGuruPageState();
}

class _ChatGuruPageState extends State<ChatGuruPage> {
  final TextEditingController _messageController = TextEditingController();
  final ChatService _chatService = ChatService();

  String? roomId;

  @override
  void initState() {
    super.initState();

    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    roomId = _chatService.getRoomId(widget.guruId, user.uid);

    _chatService.createChatRoomIfNotExists(
      guruId: widget.guruId,
      siswaId: user.uid,
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    if (user == null || roomId == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Chat - ${widget.guruName}"),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _chatService.getMessages(roomId!),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text("Error: ${snapshot.error}"),
                  );
                }

                if (snapshot.connectionState ==
                    ConnectionState.waiting) {
                  return const Center(
                      child: CircularProgressIndicator());
                }

                if (!snapshot.hasData ||
                    snapshot.data!.docs.isEmpty) {
                  return const Center(
                      child: Text("Belum ada pesan"));
                }

                return ListView(
                  padding: const EdgeInsets.all(10),
                  children: snapshot.data!.docs.map((doc) {
                    final data =
                        doc.data() as Map<String, dynamic>;
                    final isMe =
                        data['senderId'] == user.uid;

                    return Align(
                      alignment: isMe
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        margin: const EdgeInsets.symmetric(
                            vertical: 4),
                        decoration: BoxDecoration(
                          color: isMe
                              ? Colors.blue
                              : Colors.grey[300],
                          borderRadius:
                              BorderRadius.circular(16),
                        ),
                        child: Text(
                          data['message'] ?? '',
                          style: TextStyle(
                            color: isMe
                                ? Colors.white
                                : Colors.black,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _messageController,
                  decoration: const InputDecoration(
                    hintText: "Tulis pesan...",
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: () async {
                  if (_messageController.text
                      .trim()
                      .isEmpty) return;

                  await _chatService.sendMessage(
                    roomId: roomId!,
                    senderId: user.uid,
                    message:
                        _messageController.text.trim(),
                  );

                  _messageController.clear();
                },
              )
            ],
          )
        ],
      ),
    );
  }
}
