import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'services/chat_service.dart';
import 'chat_guru_detail_page.dart';

class ChatGuruListPage extends StatelessWidget {
  ChatGuruListPage({super.key});

  final ChatService _chatService = ChatService();
  final String guruId = FirebaseAuth.instance.currentUser!.uid;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Chat Masuk")),
      body: StreamBuilder<QuerySnapshot>(
        stream: _chatService.getChatsForGuru(guruId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.data!.docs.isEmpty) {
            return const Center(child: Text("Belum ada chat"));
          }

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;

              return ListTile(
                title: Text("Siswa"),
                subtitle: Text(data['lastMessage']),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => ChatGuruDetailPage(
                        roomId: doc.id,
                        siswaId: data['siswaId'],
                      ),
                    ),
                  );
                },
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
