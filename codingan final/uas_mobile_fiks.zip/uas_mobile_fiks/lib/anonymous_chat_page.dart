import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'services/anonymous_chat_service.dart';

class AnonymousChatPage extends StatefulWidget {
  final String category; // akademik / non_akademik

  const AnonymousChatPage({super.key, required this.category});

  @override
  State<AnonymousChatPage> createState() => _AnonymousChatPageState();
}

class _AnonymousChatPageState extends State<AnonymousChatPage> {
  final service = AnonymousChatService();
  final topicController = TextEditingController();
  final messageController = TextEditingController();

  bool isAnonymous = false;
  String? selectedTopicId;
  String? selectedTopicTitle;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Forum ${widget.category.toUpperCase()}"),
      ),
      body: Column(
        children: [

          // ================= CREATE TOPIC =================
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: topicController,
                    decoration: const InputDecoration(
                      hintText: "Buat topik diskusi...",
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () async {
                    if (topicController.text.trim().isEmpty) return;

                    await service.createTopic(
                      category: widget.category,
                      title: topicController.text.trim(),
                    );

                    topicController.clear();
                  },
                )
              ],
            ),
          ),

          // ================= TOPIC LIST =================
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection("anonymous_chat")
                  .doc(widget.category)
                  .collection("topics")
                  .orderBy("createdAt", descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final topics = snapshot.data!.docs;

                if (topics.isEmpty) {
                  return const Center(child: Text("Belum ada topik"));
                }

                return ListView(
                  children: topics.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;

                    return ListTile(
                      title: Text(data["title"]),
                      onTap: () {
                        setState(() {
                          selectedTopicId = doc.id;
                          selectedTopicTitle = data["title"];
                        });
                      },
                    );
                  }).toList(),
                );
              },
            ),
          ),

          if (selectedTopicId != null) ...[
            const Divider(),

            Text(
              selectedTopicTitle!,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),

            // ================= MESSAGE LIST =================
            SizedBox(
              height: 250,
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance
                    .collection("anonymous_chat")
                    .doc(widget.category)
                    .collection("topics")
                    .doc(selectedTopicId)
                    .collection("messages")
                    .orderBy("timestamp")
                    .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final messages = snapshot.data!.docs;

                  return ListView(
                    children: messages.map((doc) {
                      final data = doc.data() as Map<String, dynamic>;

                      return ListTile(
                        title: Text(data["message"]),
                        subtitle: Text(data["senderName"]),
                      );
                    }).toList(),
                  );
                },
              ),
            ),

            // ================= SEND MESSAGE =================
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: messageController,
                      decoration: const InputDecoration(
                        hintText: "Tulis pesan...",
                      ),
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      Icons.person_off,
                      color: isAnonymous ? Colors.red : Colors.grey,
                    ),
                    onPressed: () {
                      setState(() {
                        isAnonymous = !isAnonymous;
                      });
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: () async {
                      if (messageController.text.trim().isEmpty) return;

                      await service.sendMessage(
                        category: widget.category,
                        topicId: selectedTopicId!,
                        message: messageController.text.trim(),
                        isAnonymous: isAnonymous,
                      );

                      messageController.clear();
                    },
                  ),
                ],
              ),
            )
          ]
        ],
      ),
    );
  }
}
