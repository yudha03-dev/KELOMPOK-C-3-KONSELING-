import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'chat_guru_page.dart';

class SelectGuruPage extends StatelessWidget {
  const SelectGuruPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pilih Guru"),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection("gurus").snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final guruList = snapshot.data!.docs;

          if (guruList.isEmpty) {
            return const Center(
              child: Text("Belum ada guru terdaftar"),
            );
          }

          return ListView.builder(
            itemCount: guruList.length,
            itemBuilder: (context, index) {
              final guru = guruList[index];

              // 🔥 PAKAI UID AUTH, BUKAN DOC ID
              final String guruUid = guru['uid'];
              final String namaGuru = guru['nama'];

              return ListTile(
                title: Text(namaGuru),
                trailing: const Icon(Icons.arrow_forward_ios),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatGuruPage(
                        guruId: guruUid,
                        guruName: namaGuru,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
