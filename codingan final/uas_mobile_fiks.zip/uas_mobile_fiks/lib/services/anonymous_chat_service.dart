import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AnonymousChatService {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  String get uid => _auth.currentUser!.uid;
  String get name =>
      _auth.currentUser!.displayName ??
      _auth.currentUser!.email ??
      "User";

  // ================== CREATE TOPIC ==================
  Future<void> createTopic({
    required String category,
    required String title,
  }) async {
    await _db
        .collection("anonymous_chat")
        .doc(category)
        .collection("topics")
        .add({
      "title": title,
      "creatorId": uid,
      "createdAt": Timestamp.now(),
    });
  }

  // ================== SEND MESSAGE ==================
  Future<void> sendMessage({
    required String category,
    required String topicId,
    required String message,
    required bool isAnonymous,
  }) async {
    await _db
        .collection("anonymous_chat")
        .doc(category)
        .collection("topics")
        .doc(topicId)
        .collection("messages")
        .add({
      "message": message,
      "senderId": uid,
      "senderName": isAnonymous ? "Anonim" : name,
      "isAnonymous": isAnonymous,
      "timestamp": Timestamp.now(),
    });
  }
}
