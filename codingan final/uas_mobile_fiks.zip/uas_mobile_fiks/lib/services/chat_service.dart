import 'package:cloud_firestore/cloud_firestore.dart';

class ChatService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ================= ROOM ID =================
  String getRoomId(String guruId, String siswaId) {
    final ids = [guruId, siswaId]..sort();
    return ids.join("_");
  }

  // ================= CREATE ROOM =================
  Future<void> createChatRoomIfNotExists({
    required String guruId,
    required String siswaId,
  }) async {
    final roomId = getRoomId(guruId, siswaId);
    final roomRef = _db.collection('chat_rooms').doc(roomId);

    final doc = await roomRef.get();
    if (doc.exists) return;

    await roomRef.set({
      'guruId': guruId,
      'siswaId': siswaId,
      'lastMessage': '',
      'updateAt': Timestamp.now(),
    });
  }

  // ================= GET MESSAGES =================
  Stream<QuerySnapshot> getMessages(String roomId) {
    return _db
        .collection('chat_rooms')
        .doc(roomId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots();
  }

  // ================= SEND MESSAGE =================
  Future<void> sendMessage({
    required String roomId,
    required String senderId,
    required String message,
  }) async {
    final roomRef = _db.collection('chat_rooms').doc(roomId);

    await roomRef.collection('messages').add({
      'message': message,
      'senderId': senderId,
      'timestamp': Timestamp.now(),
    });

    await roomRef.update({
      'lastMessage': message,
      'updateAt': Timestamp.now(),
    });
  }

  // ================= CHAT LIST GURU =================
  Stream<QuerySnapshot> getChatsForGuru(String guruId) {
    return _db
        .collection('chat_rooms')
        .where('guruId', isEqualTo: guruId)
        .orderBy('updateAt', descending: true)
        .snapshots();
  }
}
