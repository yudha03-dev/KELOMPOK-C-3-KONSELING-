import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'services/chat_service.dart';

class ChatGuruDetailPage extends StatefulWidget {
  final String roomId;
  final String siswaId;

  const ChatGuruDetailPage({
    super.key,
    required this.roomId,
    required this.siswaId,
  });

  @override
  State<ChatGuruDetailPage> createState() => _ChatGuruDetailPageState();
}

class _ChatGuruDetailPageState extends State<ChatGuruDetailPage> {
  final ChatService _chatService = ChatService();
  final TextEditingController _messageController = TextEditingController();
  final String guruId = FirebaseAuth.instance.currentUser!.uid;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Chat dengan Siswa")),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _chatService.getMessages(widget.roomId),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                return ListView(
                  padding: const EdgeInsets.all(12),
                  children: snapshot.data!.docs.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final isMe = data['senderId'] == guruId;

                    return Align(
                      alignment:
                          isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        decoration: BoxDecoration(
                          color: isMe ? Colors.blue : Colors.grey[300],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          data['message'],
                          style: TextStyle(
                            color: isMe ? Colors.white : Colors.black,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),

          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _messageController,
                  decoration:
                      const InputDecoration(hintText: "Ketik pesan..."),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: () async {
                  if (_messageController.text.trim().isEmpty) return;

                  await _chatService.sendMessage(
                    roomId: widget.roomId,
                    senderId: guruId,
                    message: _messageController.text.trim(),
                  );

                  _messageController.clear();
                },
              ),
            ],
          )
        ],
      ),
    );
  }
}
