import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ForumChatPage extends StatefulWidget {
  final String category;
  final String topicId;
  final String topicTitle;

  const ForumChatPage({
    super.key,
    required this.category,
    required this.topicId,
    required this.topicTitle,
  });

  @override
  State<ForumChatPage> createState() => _ForumChatPageState();
}

class _ForumChatPageState extends State<ForumChatPage> {
  final TextEditingController _controller = TextEditingController();
  bool isAnonymous = false;

  final user = FirebaseAuth.instance.currentUser!;

  void sendMessage() async {
    if (_controller.text.trim().isEmpty) return;

    await FirebaseFirestore.instance
        .collection("anonymous_chat")
        .doc(widget.category)
        .collection("topics")
        .doc(widget.topicId)
        .collection("messages")
        .add({
      "message": _controller.text,
      "senderId": user.uid,
      "senderName": isAnonymous
          ? "Anonim"
          : (user.displayName ?? user.email),
      "isAnonymous": isAnonymous,
      "timestamp": Timestamp.now(),
    });

    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.topicTitle)),
      body: Column(
        children: [
          SwitchListTile(
            title: const Text("Kirim sebagai Anonim"),
            value: isAnonymous,
            onChanged: (val) {
              setState(() => isAnonymous = val);
            },
          ),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection("anonymous_chat")
                  .doc(widget.category)
                  .collection("topics")
                  .doc(widget.topicId)
                  .collection("messages")
                  .orderBy("timestamp")
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                return ListView(
                  children: snapshot.data!.docs.map((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final isMe = data["senderId"] == user.uid;

                    return Align(
                      alignment:
                          isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.all(8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isMe ? Colors.black : Colors.grey[300],
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              data["senderName"],
                              style: TextStyle(
                                fontSize: 12,
                                color: isMe ? Colors.white70 : Colors.black54,
                              ),
                            ),
                            const SizedBox(height: 5),
                            Text(
                              data["message"],
                              style: TextStyle(
                                color: isMe ? Colors.white : Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ),

          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _controller,
                  decoration:
                      const InputDecoration(hintText: "Tulis pesan..."),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.send),
                onPressed: sendMessage,
              )
            ],
          ),
        ],
      ),
    );
  }
}
