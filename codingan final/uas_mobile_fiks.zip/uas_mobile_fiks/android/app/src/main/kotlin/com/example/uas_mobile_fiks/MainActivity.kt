package com.example.uas_mobile_fiks

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
