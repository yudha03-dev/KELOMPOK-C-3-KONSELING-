import 'package:flutter/material.dart';
import 'home_screen.dart';

class ChatGuruScreen extends StatelessWidget {
  const ChatGuruScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // 🎨 Warna bisa kamu ubah sesuka hati
    const Color primaryColor = Color(0xFF1E1E1E);
    const Color secondaryColor = Color(0xFF2A2A2A);
    const Color accentColor = Colors.greenAccent;

    final teachers = [
      {'name': 'Pak Budi', 'subject': 'BK'},
      {'name': 'Ibu Siti', 'subject': 'BK'},
      {'name': 'Pak Andi', 'subject': 'BK'},
    ];

    return Scaffold(
      backgroundColor: primaryColor,
      appBar: AppBar(
        backgroundColor: secondaryColor,
        title: const Text(
          'PILIH GURU BK',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (_) => const HomeScreen()),
            );
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: teachers.length,
          itemBuilder: (ctx, i) {
            final t = teachers[i];
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: secondaryColor,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withValues(alpha: 0.3),
                    blurRadius: 4,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: ListTile(
                title: Text(
                  t['name']!,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  t['subject']!,
                  style: const TextStyle(color: Colors.grey),
                ),
                trailing: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentColor,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => ChatRoomScreen(teacherName: t['name']!),
                      ),
                    );
                  },
                  child: const Text('Chat'),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ChatRoomScreen extends StatefulWidget {
  final String teacherName;
  const ChatRoomScreen({super.key, required this.teacherName});

  @override
  State<ChatRoomScreen> createState() => _ChatRoomScreenState();
}

class _ChatRoomScreenState extends State<ChatRoomScreen> {
  final _controller = TextEditingController();
  final List<Map<String, String>> _messages = [];
  bool _anonymous = true;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _send({required bool anonymous}) {
    final txt = _controller.text.trim();
    if (txt.isEmpty) return;
    _messages.add({'from': anonymous ? 'Anonim' : 'Saya', 'text': txt});
    _controller.clear();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // 🎨 Warna bisa diubah sesuai keinginan
    const Color primaryColor = Color(0xFF1E1E1E);
    const Color secondaryColor = Color(0xFF2A2A2A);
    const Color accentColor = Colors.greenAccent;

    return Scaffold(
      backgroundColor: primaryColor,
      appBar: AppBar(
        backgroundColor: secondaryColor,
        title: Text(
          'Chat ${widget.teacherName}',
          style: const TextStyle(color: Colors.white),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (ctx, i) {
                final m = _messages[i];
                final isMe = m['from'] == 'Saya';
                return Align(
                  alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isMe ? accentColor : secondaryColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          m['from']!,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: isMe ? Colors.black : Colors.grey[300],
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          m['text']!,
                          style: TextStyle(
                            color: isMe ? Colors.black : Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            color: secondaryColor,
            child: Row(
              children: [
                Switch(
                  value: _anonymous,
                  onChanged: (v) => setState(() => _anonymous = v),
                  activeColor: accentColor,
                ),
                const Text('Anonim', style: TextStyle(color: Colors.white)),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: const TextStyle(color: Colors.white),
                    decoration: InputDecoration(
                      hintText: 'Ketik pesan...',
                      hintStyle: const TextStyle(color: Colors.grey),
                      filled: true,
                      fillColor: primaryColor,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.white),
                  onPressed: () => _send(anonymous: _anonymous),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
