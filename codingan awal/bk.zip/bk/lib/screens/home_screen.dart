import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/auth_provider.dart';
import 'chat_guru_screen.dart';
import 'forum_screen.dart';
import 'profile_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final name = auth.username ?? "Pengguna";

    // 🎨 Ubah warna sesukamu di sini
    final Color primaryColor = Colors.black; // warna tombol utama
    final Color secondaryColor = Colors.grey.shade700; // warna kotak background
    final Color backgroundColor = Colors.white; // warna latar belakang utama
    final Color textColor = Colors.black; // warna teks utama
    final Color buttonTextColor = Colors.white; // warna teks tombol
    final Color profileButtonColor = Colors.grey.shade400; // warna tombol profil

    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            bool isMobile = constraints.maxWidth < 600;
            double boxPadding = isMobile ? 16 : 32;

            return Padding(
              padding: EdgeInsets.all(boxPadding),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  // ======= Header =======
                  Text(
                    "SELAMAT DATANG",
                    style: TextStyle(
                      fontSize: isMobile ? 24 : 32,
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  Text(
                    name.toUpperCase(),
                    style: TextStyle(
                      fontSize: isMobile ? 20 : 26,
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 30),

                  // ======= Kotak Menu Utama =======
                  Expanded(
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: secondaryColor,
                        borderRadius: BorderRadius.circular(16),
                      ),
                      padding: EdgeInsets.all(isMobile ? 16 : 24),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          // Chat Guru
                          _menuButton(
                            context,
                            title: "CHAT GURU",
                            color: primaryColor,
                            textColor: buttonTextColor,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const ChatGuruScreen(),
                                ),
                              );
                            },
                          ),

                          // Akademik & Non Akademik
                          Row(
                            children: [
                              Expanded(
                                child: _menuButton(
                                  context,
                                  title: "AKADEMIK",
                                  color: primaryColor,
                                  textColor: buttonTextColor,
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => const ForumScreen(
                                          isAcademic: true,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: _menuButton(
                                  context,
                                  title: "NON AKADEMIK",
                                  color: primaryColor,
                                  textColor: buttonTextColor,
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => const ForumScreen(
                                          isAcademic: false,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),

                          // Riwayat Chat
                          _menuButton(
                            context,
                            title: "RIWAYAT CHAT",
                            color: primaryColor,
                            textColor: buttonTextColor,
                            onTap: () {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content:
                                      Text("Fitur Riwayat Chat coming soon"),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ======= Tombol Profil =======
                  FloatingActionButton.extended(
                    backgroundColor: profileButtonColor,
                    elevation: 4,
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ProfileScreen(),
                        ),
                      );
                    },
                    label: Text(
                      "PROFIL",
                      style: TextStyle(
                        color: textColor,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  // ======= Widget tombol menu =======
  Widget _menuButton(
    BuildContext context, {
    required String title,
    required Color color,
    required Color textColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 60,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 5,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
              color: textColor,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.1,
            ),
          ),
        ),
      ),
    );
  }
}
